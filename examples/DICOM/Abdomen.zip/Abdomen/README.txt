The DICOM example contained here is courtesy of the Geant4 Collaboration.
The file was taken from Geant4's examples/extended/medical/DICOM